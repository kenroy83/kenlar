<h1>osTicket requires short open tags enabled</h1>
<p>Unfortunately osTicket requires that <b>short_open_tag</b> be on. We plan on removing the requirement in the upcoming version(s). Our apologies for the inconvienence.</p>
<h2>Enabling short_open_tag</h2>
<p>Depending on your server permission level - the directive can be set on in php.ini, .htaccess or httpd.conf.</p>
  
