<h1>Configuration file missing!</h1>
<p>Required configuration file is missing - please make sure you uploaded all files in 'upload' folder or refer to the <a href="http://osticket.com/wiki/" target="_blank">Installation Guide</a>. However, if you are trying to upgrade the system then <a href="upgrade.php" >click here</a>.</p>
<p>If you believe this is in error, please get technical help from developers.</p>
<br>
<br><br>
