 <div style="clear:both"></div> 
 </div>
 <div id="footer">Copyright &copy; osTicket.com. All rights reserved</div>
 <div align="center">
    <!--> As a show of support, we ask that you leave powered by osTicket link to help spread the word. Thank you! -->
     <a id="powered_by" href="http://osticket.com"><img src="./images/poweredby.jpg" width="126" height="23" alt="Powered by osTicket"></a></div>
</div>
</body>
</html>
